# Whole-Life FS Package Guide


Files Included:
- `clients_test/README.md` (this file)
- `clients_test/demo.ipynb` (examples)
- `clients_test/fs369_segment_index.parquet` (raw-query index)
- `fs369_package.hdf5`
- `fs369_raw.hdf5`

## Dataset At A Glance

This dataset describes one full experiment lifecycle (`fs369`) from start to endpoint:
- neural activity event detections (`events`)
- 30kHz-resolution raw activity samples (`raw`)
- stimulation logs and stimulation parameters (`stimulations`)
- incubator environment monitoring (`temperature`, `humidity`, `CO2`, `O2`, `pressure`, `door_opening`)
- experiment-level contextual metadata (`metadata`)


The data export is delivered as 2 HDF5 files:

```text
fs369_package.hdf5
├── /fs369_wholelife_events
├── /fs369_wholelife_incubator_CO2
├── /fs369_wholelife_incubator_O2
├── /fs369_wholelife_incubator_door_opening
├── /fs369_wholelife_incubator_humidity
├── /fs369_wholelife_incubator_pressure
├── /fs369_wholelife_incubator_temperature
├── /fs369_wholelife_metadata
└── /fs369_wholelife_stimulations

fs369_raw.hdf5
├── /fs369_wholelife_metadata
└── /fs369_wholelife_raw
```

The files are split so the lighter `package` file can be copied or shared without including the raw data, when the raw table is not needed. This is useful because the raw spike table is much larger than all the other tables combined.


## What Is In Each File

`fs369_package.hdf5` contains:
- event/spike summary data
- stimulation data
- incubator monitoring data
- one-row metadata table for the experiment

`fs369_raw.hdf5` contains:
- raw spike table
- one-row metadata table for the experiment


## Segment Index (Fast Raw Queries)

The raw table (`/fs369_wholelife_raw`) is large. To avoid scanning the full HDF5 table for every query, use:

- `clients_test/fs369_segment_index.parquet`

This parquet file is a precomputed index that maps time windows and electrodes to row ranges in the raw HDF5 table.

It contains columns:
- `electrode`
- `t_start`
- `t_end`
- `row_start`
- `row_end`

Workflow:
1. Filter index rows by requested time window (and optional electrode list).
2. Read only matching row ranges from `/fs369_wholelife_raw` with `HDFStore.select(..., start=..., stop=...)`.
3. Apply a final exact time/electrode filter on the concatenated chunks.

This is the recommended approach to query raw recordings in a time window (see `query_raw_time_range()` function in `demo_utils.py`).



## Table Schemas

`/fs369_wholelife_metadata`
- one row
- columns include:
  - `Title` 
  - `Batch Name` 
  - `Batch Start` - date of creation of neurospheres
  - `Date` - date of first recording
  - `Dead Date` - date of death
  - `Lifespan` - lifespan from the first recording
  - `Dead Cause` 
  - `MEA_date` - date of creation of the MEA
  - `medium changes` - dates of change of medium during lifespan
  - `Medium` 
  - `Number of NS` - number of nerospheres on the MEA
  - `Reagents` - list of mediums componenents
  - `setup` - setup of the MEA (4x8 is the air-liquid-interface setup with 4 slots of 8 electrodes)

`/fs369_wholelife_events`
- one row per detected spike event
- columns:
  - `electrode` 
  - `time_of_event`
  - `max_voltage_uv`

`/fs369_wholelife_raw`
- one row per raw spike sample
- columns:
  - `electrode`
  - `time`
  - `voltage_uv`

`/fs369_wholelife_stimulations`
- one row per stimulation trigger
- columns:
  - `electrode`
  - `time_of_stim`
  - stimulation settings such as:
    - `a1`
    - `a2`
    - `enable_amp`
    - `enable_chargerecovery`
    - `d1`
    - `d2`
    - `nb_stim_pulse`
    - `post_stim_amp_settle`
    - `post_stim_charge_recov_off`
    - `post_stim_charge_recov_on`
    - `post_trigger_delay`
    - `pre_stim_amp_settle`
    - `pulse_train_period`
    - `refractory_period`
    - `stim_polarity` - NegativeFirst = 0, PositiveFirst = 1
    - `stim_shape` - Biphasic = 0, Biphasic With Interphase Delay = 1, Triphasic = 3

    
    The meaning of those settings can be found on the Intan RHX user guide: [Inan RHX user guide](https://intantech.com/files/Intan_RHX_user_guide.pdf) (page 22: Stimulation Functions) 

Incubator monitoring tables
- `/fs369_wholelife_incubator_door_opening` - True = opening of door, False = closing of door
- `/fs369_wholelife_incubator_temperature`
- `/fs369_wholelife_incubator_O2`
- `/fs369_wholelife_incubator_CO2`
- `/fs369_wholelife_incubator_pressure`
- `/fs369_wholelife_incubator_humidity`

Each incubator table contains:
- `time`
- `incubator_id`
- one value column matching the table name


## How To Read The Files In Python

Read tables in hdf5 file:

```python
import pandas as pd

pd.read_hdf(<file_name>, key=<table_name>)
```

With:
- file_name being `"fs369_package.hdf5"` or `"fs369_raw.hdf5"`
- table_name being for example `"fs369_wholelife_raw" `

(See file architecture at the begining of this README).

See example code to access tables inside `demo.ipynb`



## Practical Notes

- Timestamps are stored in UTC.
- The event data was generated as such: when recorded voltage passes a dynamic threshold*, we consider an event has occured. The maximum voltage in the small window following that crossing is saved, as well as the time at which it occured. 
- The raw data was generated as such: when an event is detected, raw recording is saved for 3ms around the threshold crossing (1ms before and 2ms after), at 30kHz. 
- The metadata table is duplicated in both files for convenience.

*threshold was computed as 6 times the median of the standard deviation

## Usage Recommendation
Prompting rule of thumb:
- The raw table can be extremely large. Do not load the whole raw table into memory unless you know your machine can handle it.
- For raw data, prefer queries through segment index  (using `fs369_segment_index.parquet`), then time filtering.
- For events/stimulations/incubator tables: direct time-column filtering is usually sufficient.
- Avoid full-table raw reads.

## Biological background 

For more information about the biology, checkout : 
- Neurospheres generation and other methods : [Open and remotely accessible Neuroplatform for research in wetware computing](https://pmc.ncbi.nlm.nih.gov/articles/PMC11097343/#sec23) 
- RNA sequencing :  [Transcriptome analyses of Forebrain organoids by RNA sequencing](https://finalspark.com/wp-content/uploads/2024/10/RNAseq-results_Heatmap_07.10.24.pdf )